const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");
const CHARACTERS = require("./characters.json");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static("public"));
app.get("/health", (_, res) => res.json({ ok: true }));

const rooms = new Map();
const makeCode = () => Math.random().toString(36).slice(2, 6).toUpperCase();
const cleanName = s => String(s || "Player").trim().slice(0, 18) || "Player";
const publicRoom = r => ({
  code:r.code, hostId:r.hostId, started:r.started, finished:r.finished,
  budget:r.budget, round:r.round, remaining:r.pool.length,
  players:r.players.map(p=>({id:p.id,name:p.name,cash:p.cash,team:p.team})),
  current:r.current, auction:r.auction ? {
    highBid:r.auction.highBid, highId:r.auction.highId,
    turnId:r.auction.turnId, passed:[...r.auction.passed],
    minBid:r.auction.highBid ? r.auction.highBid+5000 : 1000
  } : null
});
function emitRoom(r) { io.to(r.code).emit("state", publicRoom(r)); }
function getRoom(socket) {
  const r=rooms.get(socket.data.room);
  if (!r) throw new Error("Room tidak ditemukan.");
  return r;
}
function getPlayer(r, id) { return r.players.find(p=>p.id===id); }
function nextTurn(r, fromId) {
  const n=r.players.length;
  let idx=r.players.findIndex(p=>p.id===fromId);
  for(let k=1;k<=n;k++){
    const p=r.players[(idx+k)%n];
    if(!r.auction.passed.has(p.id) && p.cash >= (r.auction.highBid ? r.auction.highBid+5000 : 1000)) return p.id;
  }
  return null;
}
function closeAuction(r) {
  const a=r.auction, winner=a.highId ? getPlayer(r,a.highId) : null;
  if(winner){ winner.cash-=a.highBid; winner.team.push(r.current); }
  else r.pool.push(r.current);
  r.current=null; r.auction=null;
  if(r.pool.length===0) r.finished=true;
}
io.on("connection", socket => {
  socket.on("createRoom", ({name,budget}, cb=()=>{}) => {
    let code; do { code=makeCode(); } while(rooms.has(code));
    const cash=Math.max(1000,Math.min(10000000,Number(budget)||100000));
    const p={id:socket.id,name:cleanName(name),cash,team:[]};
    const r={code,hostId:socket.id,budget:cash,players:[p],pool:CHARACTERS.map((c,i)=>({...c,id:i})),round:0,started:false,finished:false,current:null,auction:null};
    rooms.set(code,r); socket.join(code); socket.data.room=code;
    cb({ok:true,code,state:publicRoom(r)});
  });
  socket.on("joinRoom", ({code,name}, cb=()=>{}) => {
    const r=rooms.get(String(code||"").toUpperCase());
    if(!r) return cb({ok:false,error:"Room tidak ditemukan."});
    if(r.started) return cb({ok:false,error:"Pertandingan sudah dimulai."});
    if(r.players.length>=4) return cb({ok:false,error:"Room sudah penuh (maksimal 4 pemain)."});
    if(r.players.some(p=>p.name.toLowerCase()===cleanName(name).toLowerCase())) return cb({ok:false,error:"Nama pemain sudah dipakai."});
    r.players.push({id:socket.id,name:cleanName(name),cash:r.budget,team:[]});
    socket.join(r.code); socket.data.room=r.code; emitRoom(r);
    cb({ok:true,code:r.code,state:publicRoom(r)});
  });
  socket.on("startGame", (_, cb=()=>{}) => {
    try { const r=getRoom(socket); if(socket.id!==r.hostId) throw Error("Hanya host yang bisa memulai.");
      if(r.players.length<2) throw Error("Butuh minimal 2 pemain.");
      if(r.started) throw Error("Game sudah dimulai.");
      r.started=true; emitRoom(r); cb({ok:true});
    } catch(e){cb({ok:false,error:e.message});}
  });
  socket.on("spin", (_, cb=()=>{}) => {
    try { const r=getRoom(socket); if(socket.id!==r.hostId) throw Error("Hanya host yang bisa memutar roda.");
      if(!r.started||r.finished||r.auction) throw Error("Belum bisa memutar roda.");
      if(!r.pool.length){r.finished=true;emitRoom(r);return cb({ok:true});}
      const i=Math.floor(Math.random()*r.pool.length); r.current=r.pool.splice(i,1)[0]; r.round++;
      r.auction={highBid:0,highId:null,turnId:r.players[0].id,passed:new Set()};
      emitRoom(r); cb({ok:true});
    } catch(e){cb({ok:false,error:e.message});}
  });
  socket.on("bid", (_, cb=()=>{}) => {
    try { const r=getRoom(socket), a=r.auction, p=getPlayer(r,socket.id);
      if(!a||!p||a.turnId!==socket.id) throw Error("Bukan giliran bidding kamu.");
      const amount=a.highBid ? a.highBid+5000 : 1000;
      if(p.cash<amount) throw Error("Saldo tidak cukup. Silakan pass.");
      a.highBid=amount; a.highId=p.id; a.passed.delete(p.id);
      const nxt=nextTurn(r,p.id);
      if(!nxt) closeAuction(r); else a.turnId=nxt;
      emitRoom(r); cb({ok:true});
    } catch(e){cb({ok:false,error:e.message});}
  });
  socket.on("pass", (_, cb=()=>{}) => {
    try { const r=getRoom(socket), a=r.auction;
      if(!a||a.turnId!==socket.id) throw Error("Bukan giliran kamu.");
      a.passed.add(socket.id);
      const eligible=r.players.filter(p=>!a.passed.has(p.id)&&p.cash>=(a.highBid?a.highBid+5000:1000));
      if(eligible.length===0 || (a.highId && r.players.every(p=>p.id===a.highId||a.passed.has(p.id)))) closeAuction(r);
      else { const nxt=nextTurn(r,socket.id); if(nxt) a.turnId=nxt; else closeAuction(r); }
      emitRoom(r); cb({ok:true});
    } catch(e){cb({ok:false,error:e.message});}
  });
  socket.on("disconnect",()=>{
    const r=rooms.get(socket.data.room); if(!r)return;
    // Keep disconnected players in the room state; their turns can be passed by the host.
    const p=getPlayer(r,socket.id); if(p)p.connected=false;
    emitRoom(r);
  });
});
const port=process.env.PORT||3000;
server.listen(port,()=>console.log(`Fictional War online listening on ${port}`));
