# Fictional War Online

Prototype multiplayer online untuk 2–4 pemain, budget default 100.000, pool 100 karakter, lelang manual.

## Menjalankan di komputer sendiri
1. Install Node.js 18 atau lebih baru.
2. Ekstrak folder proyek.
3. Buka terminal di folder proyek.
4. Jalankan `npm install`
5. Jalankan `npm start`
6. Buka `http://localhost:3000` di browser.

Agar teman dari jaringan internet berbeda dapat bergabung, deploy folder ini ke layanan hosting Node.js yang mendukung WebSocket (misalnya Render) dan gunakan URL HTTPS yang diberikan hosting.

## Deploy ke Render
1. Upload folder proyek ke repository GitHub.
2. Buat Web Service baru di Render dan hubungkan repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Render akan memberi URL publik. Bagikan URL tersebut kepada teman.

## Aturan prototipe
- Host membuat room, memilih budget, lalu membagikan kode.
- 2–4 pemain dapat bergabung sebelum pertandingan dimulai.
- Host memutar roda; server memilih karakter dari pool.
- Giliran bidding berjalan bergantian; bid awal 1.000, kenaikan berikutnya 5.000.
- Pemain yang tidak punya saldo cukup tidak dapat melakukan bid.
- Hasil akhir memakai skor sederhana: Tier×5 + Hax×3 + Cosmology×4 per karakter, ditambah skor karakter tertinggi.
- Disconnect belum memiliki fitur reconnect/transfer host; refresh halaman dapat membuat pemain keluar dari sesi. Untuk penggunaan publik perlu ditambah reconnect, validasi nama, moderasi, dan persistence.

## Catatan
Karakter orisinal dan karakter dari berbagai franchise hanya dipakai sebagai data fan-made untuk permainan. Power-scaling lintas-universe bersifat interpretatif; skor di sini bukan penilaian resmi.
